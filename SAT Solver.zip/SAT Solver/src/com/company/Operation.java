package com.company;

public interface Operation {
    boolean calculate(Expression exp1, Expression exp2);
}


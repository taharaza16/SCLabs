package com.company;

import static org.junit.Assert.*;

/**
 * Created by Taha-PC on 3/2/2017.
 */
public class MainTest {
    @org.junit.Test
    public void main() throws Exception {

    }

}